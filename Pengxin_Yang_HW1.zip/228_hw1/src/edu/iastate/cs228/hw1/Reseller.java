package edu.iastate.cs228.hw1;
/**
 * a subclass of abstract class TownCell
 * @author Pengxin
 *
 */

public class Reseller extends TownCell {
	/**
	 * constructor of Reseller
	 * @param p
	 * @param r
	 * @param c
	 */
	
	public 	Reseller(Town p, int r, int c) {
		// TODO Auto-generated constructor stub
		super(p, r, c);
	}
	/**
	 * a method which return the state of the Reseller TownCell
	 * @return the cell state
	 * @override
	 */

	@Override
	public State who() {
		// TODO Auto-generated method stub
		return State.RESELLER;
	}
	/**
	 * a method produce the next towncell of the old towncell 
	 * @return a new TownCell which has the new state
	 */

	@Override
	public TownCell next(Town tNew) 
	{	
		if (plain.grid[row][col].nCensus[CASUAL] <= 3)
		{
			return new Empty(tNew,row,col); 
		}
		else if(plain.grid[row][col].nCensus[EMPTY] >= 3)
		{
			return new Empty(tNew,row,col); 
		}
		else if(plain.grid[row][col].nCensus[CASUAL] > 4)
		{
			return new Streamer(tNew,row,col);
		}
		else
		{
			return new Reseller(tNew,row,col);
		}
	}

}
