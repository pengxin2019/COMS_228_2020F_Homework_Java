package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
/**
 * Junit test for Outage
 * @author Pengxin
 *
 */

public class OutageTest 
{
	/**
	 * test the who method of Outage class
	 */
	@Test
	public void testWho()
	{
		Town town = new Town(3,4);
		Outage c = new Outage(town,1,2);
		assertEquals(c.who(), State.OUTAGE);
	}
}
