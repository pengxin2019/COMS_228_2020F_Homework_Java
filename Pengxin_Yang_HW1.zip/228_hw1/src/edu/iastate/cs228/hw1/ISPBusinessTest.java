package edu.iastate.cs228.hw1;

public class ISPBusinessTest 
{

	public static void main(String []args)
	{
		Town town = new Town(4,4);
		town.randomInit(123);
		System.out.println(town.grid[0][2].who());

		System.out.println(town.grid[1][2].who());

		System.out.println(town.grid[1][2].nCensus[1]);
		System.out.println(town.grid[1][2].nCensus[3]);

		System.out.println(town);
		System.out.println(ISPBusiness.updatePlain(town));
	}
}
//plain.grid[row][col].nCensus[EMPTY] +  plain.grid[row][col].nCensus[OUTAGE]) <= 1