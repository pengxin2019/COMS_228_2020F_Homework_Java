package edu.iastate.cs228.hw4;
/**
 * @author Pengxin Yang
 */
/**
 * a MsgTree class that can create a binary tree object 
 * it can also returning a node when it is a leaf. 
 *
 */
public class MsgTree 
{
	/**
	 * the char in the string at a specific position when recursive
	 */
	public char payloadChar;
	
	/**
	 *   MsgTree  on the left
	 */
	public MsgTree left;
	
	/**
	 *   MsgTree  on the right
	 */
	public MsgTree right;

	/**
	 *   static char idx to the tree string for recursive solution 
	 *   (static means it is independent of the class or the method that it is used)
	 */
	private static int staticCharIdx = -1;  
	
	/**
	 * Constructor building the root MsgTree from the given string
	 * @param encodingString
	 */
		public MsgTree(String encodingString)
		{
			staticCharIdx++;
			if(staticCharIdx < encodingString.length())
			{
				if(encodingString.charAt(staticCharIdx) == '^') // recursive case
				{
					payloadChar = '^';
					left = new MsgTree(encodingString);
					if (staticCharIdx != encodingString.length() - 1)
					{
						right = new MsgTree(encodingString);
					}
					else // only one child
					{
						right = null;
					} 
				}
				else // base case (leaf): encodingString.charAt(staticCharIdx) != '^'
				{
					payloadChar = encodingString.charAt(staticCharIdx);
				}
			}
		}
		
		/**
		 * 	Constructor for a single node with null children (leaf nodes)
		 * @param payloadChar
		 */
		public MsgTree(char payloadChar)
		{
			//Create a MsgTree node containing the provided payloadChar.
			this.payloadChar = payloadChar;
		}
		/**
		 * method to print characters and their binary codes
		 * @param root
		 * @param code
		 */
	public static void printCodes(MsgTree root, String code)
	{
		if(root.payloadChar != '^')//leaf
		{
			if(root.payloadChar == '\n')// when there are 3 rows in the arch file, there is a new line symbol between row 2 and row 3
			{
				System.out.println("\\n" + "   " + code);
			} 
			else
			{
				System.out.println(root.payloadChar + "   " + code);
			}
		}
		if(root.left != null)
		{
			printCodes(root.left,  code + "0");
		}
		if(root.right != null)
		{
			printCodes(root.right,  code + "1");
		}
	}
	 
}

