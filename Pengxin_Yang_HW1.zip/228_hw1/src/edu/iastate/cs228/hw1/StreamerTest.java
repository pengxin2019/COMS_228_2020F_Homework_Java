package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
/**
 * Junit test for Streamer class
 * @author Pengxin
 *
 */

public class StreamerTest
{
	/**
	 * test the who method of Streamer class
	 */
	@Test
	public void testWho()
	{
		Town town = new Town(3,4);
		Streamer c = new Streamer(town,1,2);
		assertEquals(c.who(), State.STREAMER);
	}
}
