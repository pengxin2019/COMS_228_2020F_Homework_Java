package edu.iastate.cs228.hw1;
/**
 * subclass of abstract class TownCell
 *
 * @author Pengxin
 *
 */

public class Outage extends TownCell{
	/**
	 * construcotor of the Outage TownCell
	 * @param p
	 * @param r
	 * @param c
	 */
	
	public 	Outage (Town p, int r, int c) {
		// TODO Auto-generated constructor stub
		super(p, r, c);
	}
	/**
	 * A method return the state of the current towncell
	 * @return state
	 */

	@Override
	public State who() {
		// TODO Auto-generated method stub
		return State.OUTAGE;
	}
	/**
	 * a method return a new towncell which has the new state of the current Outage towncell
	 * @param tNeW
	 */

	@Override
	public TownCell next(Town tNew) 
	{	
		return new Empty(tNew,row,col); 
	}

}
