package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
/**
 * Junit test for the Reseller class
 * @author Pengxin
 *
 */

public class ResellerTest 
{
	/**
	 * test the who method of Reseller class
	 */
	@Test
	public void testWho()
	{
		Town town = new Town(3,4);
		Reseller c = new Reseller(town,1,2);
		assertEquals(c.who(), State.RESELLER);
	}

}
