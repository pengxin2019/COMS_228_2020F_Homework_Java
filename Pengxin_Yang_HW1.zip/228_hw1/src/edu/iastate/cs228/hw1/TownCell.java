package edu.iastate.cs228.hw1;

/**
 * abstract class for casual,empty, outage,reseller and streamer sublcasses
 * @author <<Pengxin Yang>>
 *	Also provide appropriate comments for this class
 *
 */
public abstract class TownCell 
{
	/**
	 * protected variable representing a town object
	 */

	protected Town plain;
	/**
	 * protected variable representing a row of the towncell
	 */
	protected int row;
	/**
	 * protected variable representing the coll of the towncell
	 */
	protected int col;//The protected variable col and row represent the index or position of that townCell object in the grid. 

	
	
	// constants to be used as indices.
	protected static final int RESELLER = 0;
	protected static final int EMPTY = 1;
	protected static final int CASUAL = 2;
	protected static final int OUTAGE = 3;
	protected static final int STREAMER = 4;
	
	public static final int NUM_CELL_TYPE = 5;
	
	//Use this static array to take census.
	public static final int[] nCensus = new int[NUM_CELL_TYPE];
	//nCensus is static final it's the same for all instances of the class TownCell and it's sub classes. 
	/**
	 * a constructor of the Towncell
	 * @param p
	 * @param r
	 * @param c
	 */

	public TownCell(Town p, int r, int c) {
		plain = p;
		row = r;
		col = c;
	}
	
	/**
	 * Censuses all cell types in the 2x3, 2x2,3x2 and 3 X 3 neighborhood
	 * Use who() method to get who is present in the 
	 *  
	 * @param counts of all customers
	 */
	public void census(int nCensus[]) {
		// zero the counts of all customers
		nCensus[RESELLER] = 0; 
		nCensus[EMPTY] = 0; 
		nCensus[CASUAL] = 0; 
		nCensus[OUTAGE] = 0; 
		nCensus[STREAMER] = 0; 

		//TODO: Write your code here.
		
		
		if (row == 0 && col == 0)//left up corner
		{
			for (int i = 0; i < 2; i++)//row
			{
				for (int j = 0; j < 2; j++)//col
				{
					if (!(i == 0 && j == 0))
					{
						if (plain.grid[i+row][j+col].who() == State.RESELLER)
						{
							nCensus[RESELLER]++;
						}
						if (plain.grid[i+row][j+col].who() == State.EMPTY)
						{
							nCensus[EMPTY]++;
						}
						if (plain.grid[i+row][j+col].who() == State.CASUAL)
						{
							nCensus[CASUAL]++;
						}
						if (plain.grid[i+row][j+col].who() == State.OUTAGE)
						{
							nCensus[OUTAGE]++;
						}
						if (plain.grid[i+row][j+col].who() == State.STREAMER)
						{
							nCensus[STREAMER]++;
						}
					}
				}
			}
		}
		if (row != 0 && row < plain.getWidth() - 1 &&  col == 0)//left border
		{
			for (int i = -1; i < 2; i++)//row
			{
				for (int j = 0; j < 2; j++)//col
				{
					if (!(i == 0 && j == 0))
					{
						if (plain.grid[i+row][j+col].who() == State.RESELLER)
						{
							nCensus[RESELLER]++;
						}
						if (plain.grid[i+row][j+col].who() == State.EMPTY)
						{
							nCensus[EMPTY]++;
						}
						if (plain.grid[i+row][j+col].who() == State.CASUAL)
						{
							nCensus[CASUAL]++;
						}
						if (plain.grid[i+row][j+col].who() == State.OUTAGE)
						{
							nCensus[OUTAGE]++;
						}
						if (plain.grid[i+row][j+col].who() == State.STREAMER)
						{
							nCensus[STREAMER]++;
						}
					}
				}
				
			}	
				
		}
		if (row == plain.getWidth() - 1 && col == 0)//left bottom corner
		{
			for (int i = -1; i < 1; i++)
			{
				for (int j = 0; j < 2; j++)
				{
					if (!(i == 0 && j == 0))
					{
						if (plain.grid[i+row][j+col].who() == State.RESELLER)
						{
							nCensus[RESELLER]++;
						}
						if (plain.grid[i+row][j+col].who() == State.EMPTY)
						{
							nCensus[EMPTY]++;
						}
						if (plain.grid[i+row][j+col].who() == State.CASUAL)
						{
							nCensus[CASUAL]++;
						}
						if (plain.grid[i+row][j+col].who() == State.OUTAGE)
						{
							nCensus[OUTAGE]++;
						}
						if (plain.grid[i+row][j+col].who() == State.STREAMER)
						{
							nCensus[STREAMER]++;
						}
					}
				}
			}
		}
		if (row == plain.getWidth() - 1 && col != 0 && col != plain.getLength() - 1)//bottom border
		{
			for (int i = -1; i < 1; i++)
			{
				for (int j = -1; i < 2; j++)
				{
					if(!(i == 0 & j == 0))
					{
						if (plain.grid[i+row][j+col].who() == State.RESELLER)
						{
							nCensus[RESELLER]++;
						}
						if (plain.grid[i+row][j+col].who() == State.EMPTY)
						{
							nCensus[EMPTY]++;
						}
						if (plain.grid[i+row][j+col].who() == State.CASUAL)
						{
							nCensus[CASUAL]++;
						}
						if (plain.grid[i+row][j+col].who() == State.OUTAGE)
						{
							nCensus[OUTAGE]++;
						}
						if (plain.grid[i+row][j+col].who() == State.STREAMER)
						{
							nCensus[STREAMER]++;
						}
					}
				}
			}
		}
		if (row == plain.getWidth() - 1 && col == plain.getLength() - 1)// right bottom corner
		{
			for (int i = -1; i < 1;i++)
			{
				for (int j = -1; j < 1; j++)
				{
					if(!(i == 0 && j == 0))
					{
						if (plain.grid[i+row][j+col].who() == State.RESELLER)
						{
							nCensus[RESELLER]++;
						}
						if (plain.grid[i+row][j+col].who() == State.EMPTY)
						{
							nCensus[EMPTY]++;
						}
						if (plain.grid[i+row][j+col].who() == State.CASUAL)
						{
							nCensus[CASUAL]++;
						}
						if (plain.grid[i+row][j+col].who() == State.OUTAGE)
						{
							nCensus[OUTAGE]++;
						}
						if (plain.grid[i+row][j+col].who() == State.STREAMER)
						{
							nCensus[STREAMER]++;
						}
					}
				}
			}
		}
		if (row != 0 && row < plain.getWidth() - 1 && col == plain.getLength() - 1)//right border
		{
			for (int i = -1; i < 2; i++)
			{
				for (int j = -1; j < 1; j++)
				{
					if (!(i == 0 && j == 0))
					{
						if (plain.grid[i+row][j+col].who() == State.RESELLER)
						{
							nCensus[RESELLER]++;
						}
						if (plain.grid[i+row][j+col].who() == State.EMPTY)
						{
							nCensus[EMPTY]++;
						}
						if (plain.grid[i+row][j+col].who() == State.CASUAL)
						{
							nCensus[CASUAL]++;
						}
						if (plain.grid[i+row][j+col].who() == State.OUTAGE)
						{
							nCensus[OUTAGE]++;
						}
						if (plain.grid[i+row][j+col].who() == State.STREAMER)
						{
							nCensus[STREAMER]++;
						}
					}
				}
			}
		}
		if (row == 0 && col == plain.getLength() - 1 )//right up corner
		{
			for(int i = 0; i < 2; i++)
			{
				for (int j = -1; j < 1; j++)
				{
					if (!(i == 0 && j == 0))
					{
						if (plain.grid[i+row][j+col].who() == State.RESELLER)
						{
							nCensus[RESELLER]++;
						}
						if (plain.grid[i+row][j+col].who() == State.EMPTY)
						{
							nCensus[EMPTY]++;
						}
						if (plain.grid[i+row][j+col].who() == State.CASUAL)
						{
							nCensus[CASUAL]++;
						}
						if (plain.grid[i+row][j+col].who() == State.OUTAGE)
						{
							nCensus[OUTAGE]++;
						}
						if (plain.grid[i+row][j+col].who() == State.STREAMER)
						{
							nCensus[STREAMER]++;
						}
					}
				}
			}
		}
		if (row == 0 && col != 0 && col < plain.getLength() - 1)//up border
		{
			for (int i = 0; i < 2; i++)
			{
				for (int j = -1; j < 2; j++)
				{
					if (!(i == 0 && j == 0))
					{
						if (plain.grid[i+row][j+col].who() == State.RESELLER)
						{
							nCensus[RESELLER]++;
						}
						if (plain.grid[i+row][j+col].who() == State.EMPTY)
						{
							nCensus[EMPTY]++;
						}
						if (plain.grid[i+row][j+col].who() == State.CASUAL)
						{
							nCensus[CASUAL]++;
						}
						if (plain.grid[i+row][j+col].who() == State.OUTAGE)
						{
							nCensus[OUTAGE]++;
						}
						if (plain.grid[i+row][j+col].who() == State.STREAMER)
						{
							nCensus[STREAMER]++;
						}
					}
				}
			}
		}
		if(!(row == 0 || row == plain.getWidth() - 1 || col == 0 || col == plain.getLength() - 1 ))//in the center
		{
			for (int i = -1; i < 2; i++)
			{
				for (int j = -1; j < 2; j++)
				{
					if (i == 0 && j == 0) continue;
					if (plain.grid[i+row][j+col].who() == State.RESELLER)
					{
						nCensus[RESELLER]++;
					}
					if (plain.grid[i+row][j+col].who() == State.EMPTY)
					{
						nCensus[EMPTY]++;
					}
					if (plain.grid[i+row][j+col].who() == State.CASUAL)
					{
						nCensus[CASUAL]++;
					}
					if (plain.grid[i+row][j+col].who() == State.OUTAGE)
					{
						nCensus[OUTAGE]++;
					}
					if (plain.grid[i+row][j+col].who() == State.STREAMER)
					{
						nCensus[STREAMER]++;
					}
						
					
				}
			}
		}
		
			
	}	

	/**
	 * Gets the identity of the cell.
	 * 
	 * @return State
	 */
	public abstract State who();

	/**
	 * Determines the cell type in the next cycle.
	 * 
	 * @param tNew: town of the next cycle
	 * @return TownCell
	 */
	public abstract TownCell next(Town tNew);
}
