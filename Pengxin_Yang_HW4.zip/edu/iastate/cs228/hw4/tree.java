package edu.iastate.cs228.hw4;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
/**
 * @author Pengxin Yang
 *
/**
 * a class containing a decode method and main method to unzip the arch file
 */
public class tree {
	 public static void main(String[] args) throws FileNotFoundException 
	 {
		     //Scanner for user input
		  Scanner user = new Scanner(System.in);
		  String  inputFileName = "";
	
		    // prepare the input file
		  System.out.println("Please enter filename to decode: ");
		  inputFileName = user.next();

		  
		  File inputFile = new File(inputFileName);

		  Scanner scan = new Scanner(inputFile);
		  Scanner scanLine = new Scanner(inputFile);
		  
		  //count the total number of lines
		  int numLine = 0;
		  while(scanLine.hasNextLine())
		  {
			  scanLine.nextLine();
			  numLine++;
		  }
		  
		  
		  String stringEncoding = ""; ////scan the encodingstring 
		  String binaryMsg = ""; //		  and binary message from the given file
		  
		  if(numLine == 2) // 2 rows in the arch file
		  {
			  StringBuilder str1 = new StringBuilder();
			  StringBuilder str2 = new StringBuilder();
			  
			  str1.append(scan.nextLine()); 
			  stringEncoding = str1.toString();
			  str2.append(scan.nextLine()); 
			  binaryMsg = str2.toString();
		  }
		  else if(numLine == 3)//3 rows in the arch file
		  {
			  StringBuilder str1 = new StringBuilder();
			  StringBuilder str2 = new StringBuilder();
			  StringBuilder str3 = new StringBuilder();

			  
			  str1.append(scan.nextLine()); 
			  str2.append(scan.nextLine()); 
			 
 			  stringEncoding =  str1.toString() + '\n' + str2.toString();// there is a new line symbol between row 2 and row 3

 			  str3.append(scan.nextLine()); 
			  binaryMsg = str3.toString();

		  }
		  scanLine.close();
		  user.close();
		  scan.close();
		  System.out.println(stringEncoding.length());
		  System.out.println(stringEncoding);

		  //build the tree with the given encoding string
		  MsgTree msgTree =  new MsgTree(stringEncoding);
		  
		  // returns a preorder traversal of the tree as a String
		  
		  System.out.println("character   code");
		  System.out.println("------------------");
		  String code = "";
		  msgTree.printCodes(msgTree, code);
		  
		  System.out.println("");


		  System.out.println("MESSAGE");
		  decode(msgTree, binaryMsg);
	 }
	 /**
	  * a static method that does a recursive preorder traversal of the MsgTree and prints all the characters 
	  * and their bit codes:
	  * @param codes
	  * @param msg
	  */
	 
	 public static void decode(MsgTree codes, String msg)
	 {
		 if (msg ==  null)
		 {
			 throw new NullPointerException();
		 }
		 else
		 {
			 // the given codes will  change
			 // so make a copy of the original codes before go to loop
			 MsgTree original = codes;
			 
			 int i = 0;
			 while(i < msg.length()) 
			 {
				 if(codes.payloadChar != '^')
				 {
					  System.out.print(codes.payloadChar);
					  codes = original;
				 }
				 if (msg.charAt(i) == '0')// go left
				 {
					  codes = codes.left;
					  i++;
				 }
				  else if (msg.charAt(i) == '1') // == 1, right 
				  {
						 codes = codes.right;
						 i++;
				  }
			 }
		 }
	}
}
	 
	 
	
