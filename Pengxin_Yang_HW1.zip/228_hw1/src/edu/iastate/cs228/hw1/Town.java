package edu.iastate.cs228.hw1;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;


/**
 *  @author <<Write your name here>>
 *
 */
public class Town {
	
	private int length, width;  //Row and col (first and second indices)
	public TownCell[][] grid;//The length and width in the Town class represent the actual size of the grid, not indexes

	/**
	 * Constructor to be used when user wants to generate grid randomly, with the given seed.
	 * This constructor does not populate each cell of the grid (but should assign a 2D array to it).
	 * @param length
	 * @param width
	 */
//	public Town(int length, int width) {
	public Town(int width, int length) {
	
		//TODO: Write your code here.
		this.length = length;
		this.width = width;
		this.grid = new TownCell[width][length];
	}
	
	/**
	 * Constructor to be used when user wants to populate grid based on a file.
	 * Please see that it simple throws FileNotFoundException exception instead of catching it.
	 * Ensure that you close any resources (like file or scanner) which is opened in this function.
	 * @param inputFileName
	 * @throws FileNotFoundException
	 */
	public Town(String inputFileName) throws FileNotFoundException 
	{
		//TODO: Write your code here.
		File file = new File(inputFileName);
		Scanner scanner = new Scanner(file);
		this.width = scanner.nextInt();
		this.length = scanner.nextInt();
		grid = new TownCell[this.width][this.length];
		for (int i = 0; i < width; i++)
		{
			for (int j = 0; j < length; j++)
			{
				if (scanner.hasNext())
				{
					String s = scanner.next();
					if(s.equals("C"));
					{
						grid[i][j] = new Casual(this, i, j);
					}
					if(s.equals("S"))
					{
						grid[i][j] = new Streamer(this, i, j);
					}
					if(s.equals("R"))
					{
						grid[i][j] = new Reseller(this, i, j);
					}
					if(s.equals("O"))
					{
						grid[i][j] = new Outage(this, i, j);
					}
					if(s.equals("E"))
					{
						grid[i][j] = new Empty(this, i, j);
					}
				}
					
			}
		}
		scanner.close();
	}
	
		
	/**
	 * Returns width of the grid.
	 * @return
	 */
	public int getWidth()
	{
		//TODO: Write/update your code here.
		return this.width;
	}
	
	/**
	 * Returns length of the grid.
	 * @return
	 */
	public int getLength() {
		//TODO: Write/update your code here.
		return this.length;
	}

	/**
	 * Initialize the grid by randomly assigning cell with one of the following class object:
	 * Casual, Empty, Outage, Reseller OR Streamer
	 */
	public void randomInit(int seed) {
		Random rand = new Random(seed);
		//TODO: Write your code here.
		for (int i = 0; i < this.width; i++)
		{
			for (int j = 0; j < this.length; j++)
			{
				int newRandomValue = rand.nextInt(5);
				if (newRandomValue == 0)
				{
					grid[i][j] = new Reseller(this, i, j);//the this refers to the Town object that is calling randomInit()
				}
				if (newRandomValue == 1)
				{
					grid[i][j] = new Empty(this, i, j);
				}
				if (newRandomValue == 2)
				{
					grid[i][j] = new Casual(this, i, j);
				}
				if (newRandomValue == 3)
				{
					grid[i][j] = new Outage(this, i, j);
				}
				if (newRandomValue == 4)
				{
					grid[i][j] = new Streamer(this, i, j);
				}
			}
		}
	}
	
	/**
	 * Output the town grid. For each square, output the first letter of the cell type.
	 * Each letter should be separated either by a single space or a tab.
	 * And each row should be in a new line. There should not be any extra line between 
	 * the rows.
	 */
	@Override
	public String toString() {
		String s = "";
		//TODO: Write your code here.
		for (int i = 0; i < width; i++)//row
		{
			for (int j = 0; j < length; j++)//col
			{
				
				if (this.grid[i][j].who() == State.RESELLER)
				{
					s += "R ";
				}
				if (this.grid[i][j].who() == State.EMPTY)
				{
					s += "E ";
				}
				if (this.grid[i][j].who() == State.CASUAL)
				{
					s += "C ";
				}
				if (this.grid[i][j].who() == State.OUTAGE)
				{
					s += "O ";
				}
				if (this.grid[i][j].who() == State.STREAMER)
				{
					s += "S ";
				}
				
			}
			s += "\n";
		}
		return s;
	}
}
