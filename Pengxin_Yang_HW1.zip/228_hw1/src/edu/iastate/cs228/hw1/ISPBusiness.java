package edu.iastate.cs228.hw1;
import java.io.FileNotFoundException;
import java.util.Random;
import java.util.Scanner;

/**
 * @author <<Write your name here>>
 *
 * The ISPBusiness class performs simulation over a grid 
 * plain with cells occupied by different TownCell types.
 *
 */
public class ISPBusiness {
	
	/**
	 * Returns a new Town object with updated grid value for next billing cycle.
	 * @param tOld: old/current Town object.
	 * @return: New town object.
	 */
	public static Town updatePlain(Town tOld)
	{
		Town tNew = new Town(tOld.getWidth(),tOld.getLength());
		//TODO: Write your code here.
		for (int i = 0; i < tOld.getWidth(); i++)
		{
			for(int j = 0; j < tOld.getLength(); j++)
			{
				tNew.grid[i][j] = tOld.grid[i][j].next(tNew);
			}
		}
		return tNew;
	}


	/**
	 * Returns the profit for the current state in the town grid.
	 * @param town
	 * @return
	 */
	public static int getProfit(Town town) {
		//TODO: Write/update your code here.
		int width = town.getWidth();
		int length = town.getLength();
		int countCasual = 0;
		for (int i = 0 ; i < width; i++)
		{
			for (int j = 0; j < length; j++)
			{
				if(town.grid[i][j].who() == State.CASUAL)
				{
					countCasual += 1;
				}
			}
		}
		
		return countCasual;
	}
	

	/**
	 * Main method. Interact with the user and ask if user wants to specify elements of grid
	 *  via an input file (option: 1) or wants to generate it randomly (option: 2).
	 *  
	 *  Depending on the user choice, create the Town object using respective constructor and
	 *  if user choice is to populate it randomly, then populate the grid here.
	 *  
	 *  Finally: For 12 billing cycle calculate the profit and update town object (for each cycle).
	 *  Print the final profit in terms of %. You should only print the integer part (Just print the 
	 *  integer value. Example if profit is 35.56%, your output should be just: 35).
	 *  
	 * Note that this method does not throws any exception, thus you need to handle all the exceptions
	 * in it.
	 * 
	 * @param args
	 * @throws FileNotFoundException 
	 * 
	 */
	public static void main(String []args) throws FileNotFoundException {		
		//TODO: Write your code here.
		double profit = 0.0;
		Scanner in = new Scanner(System.in);
		System.out.println("How to populate grid (type 1 or 2): 1: from a file. 2: randomly with seed");
		int option = in.nextInt();
		if (option == 1)
		{
			
			System.out.println("Please enter file path:");
			String fileName = in.next();
//			/Users/15612770360163.com/Desktop/HW1_228/ISP4x4.txt
			
			Town town = new Town(fileName);	
			profit = getProfit(town);
			for (int i = 0; i < 11; i++)
			{
				town = updatePlain(town);
				profit += getProfit(town);
			}
//			System.out.print(town.toString());
            System.out.print(profit);

//		   System.out.print(100.0*profit/(Double.valueOf(town.getLength())*Double.valueOf(town.getWidth())*12.0));
		}
		else if (option == 2)
		{

			System.out.print("Provide rows, cols and seed integer separated by spaces:");
			int givenWidth = in.nextInt();
			int givenLength = in.nextInt();
			int seed = in.nextInt();
			Town town = new Town(givenWidth, givenLength);
			
			town.randomInit(seed);
			profit += getProfit(town);
			for (int i = 0; i < 11; i++)
			{
				town = updatePlain(town);
				profit += getProfit(town);
			}
			System.out.print(100.0*profit/(Double.valueOf(town.getLength())*Double.valueOf(town.getWidth())*12.0));
		}
		else
		{
			System.out.println("Invalid numbers. Please provide rows, cols and seed integer separated by spaces:");
		}
		
	}
}
