package edu.iastate.cs228.hw3;

import java.util.AbstractSequentialList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/**
 * @author Pengxin Yang
 */
/**
 * Implementation of the list interface based on linked nodes
 * that store multiple items per node.  Rules for adding and removing
 * elements ensure that each node (except possibly the last one)
 * is at least half full.
 */
public class StoutList<E extends Comparable<? super E>> extends AbstractSequentialList<E>
{
  /**
   * Default number of elements that may be stored in each node.
   */
  private static final int DEFAULT_NODESIZE = 4;
  
  /**
   * Number of elements that can be stored in each node.
   */
  private final int nodeSize;
  
  /**
   * Dummy node for head.  It should be private but set to public here only  
   * for grading purpose.  In practice, you should always make the head of a 
   * linked list a private instance variable.  
   */
  public Node head;
  
  /**
   * Dummy node for tail.
   */
  private Node tail;
  
  /**
   * Number of elements in the list.
   */
  private int size;
  
  /**
   * Constructs an empty list with the default node size.
   */
  public StoutList()
  {
    this(DEFAULT_NODESIZE);
  }

  /**
   * Constructs an empty list with the given node size.
   * @param nodeSize number of elements that may be stored in each node, must be 
   *   an even number
   */
  public StoutList(int nodeSize)
  {
    if (nodeSize <= 0 || nodeSize % 2 != 0) throw new IllegalArgumentException();
    
    // dummy nodes
    head = new Node();
    tail = new Node();
    head.next = tail;
    tail.previous = head;
    this.nodeSize = nodeSize;
  }
  
  /**
   * Constructor for grading only.  Fully implemented. 
   * @param head
   * @param tail
   * @param nodeSize
   * @param size
   */
  public StoutList(Node head, Node tail, int nodeSize, int size)
  {
	  this.head = head; 
	  this.tail = tail; 
	  this.nodeSize = nodeSize; 
	  this.size = size; 
  }
  /**
   * return the size of the list
   */
  @Override
  public int size()
  {
    // TODO Auto-generated method stub
    return size;
  }
  
  /**
   * adds the given element to the end of the list
   * return true after it is done
   */
  @Override
  public boolean add(E item)
  {
    // TODO Auto-generated method stub
	  add(size, item);
	  return true;
  }
  /**
   * adds the given element to the given position
   */
  @Override
  public void add(int pos, E item)
  {
    // TODO Auto-generated method stub
//	  this.listIterator(size);

	  if (pos < 0 || pos > size)
	  {
		    throw new IndexOutOfBoundsException("" + pos);
	  }
	  if (item == null)
	  {
		  throw new NullPointerException();
	  }
	  
	 
	  if (size == 0)//if the list is empty, create a new node and put X at offset 0
	  {
		  Node newNode = new Node();
		  head.next = newNode;
		  tail.previous = newNode;
		  newNode.next = tail;
		  newNode.previous = head;
		  newNode.addItem(0, item);
		  size++;
	  }
	  else // the list is not empty
	  {
		  Node currentNode = find(pos).node;
		  int currenteOffset = find(pos).offset;
		 
		  Node predecessor = currentNode.previous;
		  Node successor = new Node();
		  successor.previous = currentNode;
		  successor.next = currentNode.next;
		  currentNode.next.previous = successor;
		  currentNode.next = successor;
		  
		  
		  if (currenteOffset == 0)//off = 0 
		  {
			  if (predecessor != null && predecessor.count < nodeSize && predecessor != head)//if n has a predecessor which has fewer than M elements (and is not the head)
			  {
				  predecessor.addItem(predecessor.count, item);//put X in n’s predecessor
				  ++size;

			  }
			  else if(currentNode.next == tail && predecessor.count == nodeSize)//if n is the tail node and n’s predecessor has M elements,
			  {
				  Node newNode = new Node();
				  
				  tail.previous.next = newNode;
				  newNode.previous = tail.previous;
				  tail.previous = newNode;
				  newNode.next = tail;
				  
				  newNode.addItem(0, item);//create a new node and put X at offset 0
				  ++size;

			  }
		  }
		  else if (currentNode.count < nodeSize)//if there is space in node n, put X in node n at offset off, shifting array elements as necessary
		  {
			  currentNode.addItem(currenteOffset, item);
			  ++size;
		  }
		  else //perform a split operation: move the last M/2 elements of node n into a new successor node n'
		  {
			  int i = nodeSize/2;//currentNode
			  int j = 0;//successor
			  while (i < nodeSize && j <= nodeSize/2)
			  {
				  successor.addItem(j, currentNode.data[i]);
				  currentNode.removeItem(i);
				  i++;
				  j++;
			  }
			  
			  if(currenteOffset <= nodeSize/2)//if off ≤ M/2, put X in node n at offset off
			  {
				  currentNode.addItem(currenteOffset, item);
				  ++size;
			  }
			  else if(currenteOffset > nodeSize/2)//if off > M/2, put X in node n' at offset (off − M/2)
			  {
				  successor.addItem(currenteOffset - nodeSize/2, item);
				  ++size;
			  } 
		  } 
	  }
			  
			  
  }

  /**
   * return and remove the element from the given postion in the list
   */
  
  @Override
  public E remove(int pos)
  {
    // TODO Auto-generated method stub
	  if (pos < 0 || pos > size)
	  {
		    throw new IndexOutOfBoundsException("" + pos);
	  }
	  
	  Node currentNode = find(pos).node;
	  int currenteOffset = find(pos).offset;
	  
	  Node successor = currentNode.next;
	  
	 
	  if(currentNode.next == tail && currentNode.count == 1)//if the node n containing X is the last node and has only one element, delete it;
	  {
		  E temp = currentNode.data[currenteOffset];
		  currentNode.removeItem(currenteOffset);
		  size--;
		  return temp;
	  }
	  else if(currentNode.next == tail && (currentNode.count >= 2 || currentNode.count > nodeSize/2)) // ////if n is the last node (thus with two or more elements) , or if n has more than M/2 elements, 
	  {
		  E temp = currentNode.data[currenteOffset];
		  currentNode.removeItem(currenteOffset);  // //remove X from n, shifting elements as necessary;
		  size--;
		  return temp;
	  }
	  else if(currentNode.count <= nodeSize/2)   //(the node n must have at most M/2 elements)
	  {
		  if (successor.count > nodeSize/2)   //if the successor node n' has more than M/2 elements, 
		  {
			  E temp = successor.data[0];
			  currentNode.addItem(successor.data[0]);   //move the first element from n' to n. (mini-merge)
			  successor.removeItem(0);
			  size--;
			  return temp;
		  }
		  else if(successor.count <= nodeSize/2 && successor.count >= 0)  //if the successor node n' has M/2 or fewer elements
		  {
			  int i = 0;  //// successor
			  while (i < nodeSize) //then move all elements from n' to n and delete n' (full merge)
			  {
				  if (successor.data[i] != null)
				  {
					  currentNode.addItem(successor.data[i]);
					  i++;
					  return successor.data[i];
				  }
				  else
				  {
					  i++;
					  return null;
				  }
			  }
			  successor.next.previous = currentNode; // delete successor n' node
			  currentNode.next = successor.next;
		  }
	  }
	  
    return null;
    
  }

  /**
   * Sort all elements in the stout list in the NON-DECREASING order. You may do the following. 
   * Traverse the list and copy its elements into an array, deleting every visited node along 
   * the way.  Then, sort the array by calling the insertionSort() method.  (Note that sorting 
   * efficiency is not a concern for this project.)  Finally, copy all elements from the array 
   * back to the stout list, creating new nodes for storage. After sorting, all nodes but 
   * (possibly) the last one must be full of elements.  
   *  
   * Comparator<E> must have been implemented for calling insertionSort().    
   */
  public void sort()
  {
	  // TODO 
	  exampleComparator comp = new exampleComparator();
	  E[] temp = (E[]) new Comparable[size];
	  ListIterator<E> li = listIterator();

	  for (int i = 0; i < size; i++)
	  {
		  Node currentNode = this.find(i).node;
		  int offset = find(i).offset;
		  
		  temp[i] = li.next();
		  remove(i);//remove element
		  
	  }
	  //sort the array by calling the insertionSort() method
	  insertionSort(temp, comp);
	  // copy all elements from the array back to the stout list, creating new nodes for storage
	  for (int j = 0; j < size; j++)
	  {
		  this.add(temp[j]);
	  }
  }
  
  private class exampleComparator implements Comparator<E> // Comparator is abstract, so we have to make it concrete
  {

	@Override
	public int compare(E o1, E o2) 
	{
		// TODO Auto-generated method stub
		return o1.compareTo(o2);
	}
	  
  }
  /**
   * Sort all elements in the stout list in the NON-INCREASING order. Call the bubbleSort()
   * method.  After sorting, all but (possibly) the last nodes must be filled with elements.  
   *  
   * Comparable<? super E> must be implemented for calling bubbleSort(). 
   */
  public void sortReverse() 
  {
	  // TODO 
	  E[] temp = (E[]) new Comparable[size];
	  ListIterator<E> li = listIterator();

	  for (int i = 0; i < size; i++)
	  {
		  temp[i] = li.next();
		  remove(i);//remove element
	  }
	  bubbleSort(temp);
	  
	  for (int j = 0; j < size; j++)
	  {
		  this.add(temp[j]);
	  }
  }
  /**
   * iterator
   */
  @Override
  public Iterator<E> iterator()
  {
    // TODO Auto-generated method stub
	  StoutListIterator sli = new StoutListIterator ();
	  return sli;
  }
  /**
   * an listIterator for the position 0
   */
  @Override
  public ListIterator<E> listIterator()
  {
    // TODO Auto-generated method stub
    return listIterator(0);
  }
  /**
   * an listIterator for the given index
   */
  @Override
  public ListIterator<E> listIterator(int index)//index is the postion in the whole list
  {
    // TODO Auto-generated method stub
	  StoutListIterator sliIndex = new StoutListIterator(index);
	  return sliIndex;

  }
  
  /**
   * Returns a string representation of this list showing
   * the internal structure of the nodes.
   */
  public String toStringInternal()
  {
    return toStringInternal(null);
  }

  /**
   * Returns a string representation of this list showing the internal
   * structure of the nodes and the position of the iterator.
   *
   * @param iter
   *            an iterator for this list
   */
  public String toStringInternal(ListIterator<E> iter) 
  {
      int count = 0;
      int position = -1;
      if (iter != null) {
          position = iter.nextIndex();
      }

      StringBuilder sb = new StringBuilder();
      sb.append('[');
      Node current = head.next;
      while (current != tail) {
          sb.append('(');
          E data = current.data[0];
          if (data == null) {
              sb.append("-");
          } else {
              if (position == count) {
                  sb.append("| ");
                  position = -1;
              }
              sb.append(data.toString());
              ++count;
          }

          for (int i = 1; i < nodeSize; ++i) {
             sb.append(", ");
              data = current.data[i];
              if (data == null) {
                  sb.append("-");
              } else {
                  if (position == count) {
                      sb.append("| ");
                      position = -1;
                  }
                  sb.append(data.toString());
                  ++count;

                  // iterator at end
                  if (position == size && count == size) {
                      sb.append(" |");
                      position = -1;
                  }
             }
          }
          sb.append(')');
          current = current.next;
          if (current != tail)
              sb.append(", ");
      }
      sb.append("]");
      return sb.toString();
  }


  /**
   * Node type for this list.  Each node holds a maximum
   * of nodeSize elements in an array.  Empty slots
   * are null.
   */
  
  private class Node
  {
    /**
     * Array of actual data elements.
     */
    // Unchecked warning unavoidable.
    public E[] data = (E[]) new Comparable[nodeSize];
    
    /**
     * Link to next node.
     */
    public Node next;
    
    /**
     * Link to previous node;
     */
    public Node previous;
    
    /**
     * Index of the next available offset in this node, also 
     * equal to the number of elements in this node.
     */
    public int count;
    

    /**
     * Adds an item to this node at the first available offset.
     * Precondition: count < nodeSize
     * @param item element to be added
     */
    void addItem(E item)
    {
    	if (item == null)
    	{
    		throw new NullPointerException();
    	}
      if (count >= nodeSize)
      {
        return;
      }
      data[count++] = item;
      //useful for debugging
      System.out.println("Added " + item.toString() + " at index " + count + " to node "  + Arrays.toString(data));
    }
  
    /**
     * Adds an item to this node at the indicated offset, shifting
     * elements to the right as necessary.
     * 
     * Precondition: count < nodeSize
     * @param offset array index at which to put the new element
     * @param item element to be added
     */
    void addItem(int offset, E item)
    {
    	if (item == null)
    	{
		throw new NullPointerException();
		}
    	
      if (count >= nodeSize)
      {
    	  return;
      }
      for (int i = count - 1; i >= offset; --i)
      {
        data[i + 1] = data[i];
      }
      ++count;
      data[offset] = item;
      //useful for debugging 
      System.out.println("Added " + item.toString() + " at index " + offset + " to node: "  + Arrays.toString(data));
    }

    /**
     * Deletes an element from this node at the indicated offset, 
     * shifting elements left as necessary.
     * Precondition: 0 <= offset < count
     * @param offset
     */
    void removeItem(int offset)
    {
      E item = data[offset];
      for (int i = offset + 1; i < nodeSize; ++i)
      {
        data[i - 1] = data[i];
      }
      data[count - 1] = null;
      --count;
    }    
  }
  
  /**
   * a constructor for the private NodeInfo class
   *
   */
  private class NodeInfo
  {
	  public Node node;
	  public int offset;
      public NodeInfo(Node node, int offset)
      {
    	  this.node = node;
    	  this.offset = offset; 
      }
  }
  /**
   * returns the node and offset for the given logical index
   * @param pos  the postion in the list
   */
  public NodeInfo find(int pos)
  {
	  StoutListIterator stoutListIterator = new StoutListIterator(pos);
	  NodeInfo nodeInfo = new NodeInfo (stoutListIterator.currentNode, stoutListIterator.offset);
	  return  nodeInfo;
  }
  /**
   *  StoutListIterator class
   */
  
  private class StoutListIterator implements ListIterator<E>
  {
	// constants you possibly use ...
	// direction for remove() and set()
	  private static final int BEHIND = -1;
	  private static final int AHEAD = 1; 
	  private static final int NONE = 0;

	  
	// instance variables ... 
	  private Node currentNode;// current node
	  
	  private int posList; //position of element in the whole list
	  private int offset; //offset of a node
	  private int direction; // has three states : 1/-1/0
	  	  
	  
    /**
     * Default constructor 
     */
    public StoutListIterator()
    {
    	// TODO 
    	this(0);
    }

    /**
     * Constructor finds node at a given position.
     * @param pos
     */
    public StoutListIterator(int pos)
    {
    	// TODO 
    	posList = 0; 
    	currentNode = head;  
    	if (pos < 0 || pos > size)
    	{
    		throw new IndexOutOfBoundsException ("" + pos);
    	} 
    	while(posList < pos)
    	{
    		currentNode = currentNode.next;
    		posList += currentNode.count;
    	}
    	offset = currentNode.count;
    	
//    	while (posList < pos)
//    	{
//    		currentNode = currentNode.next;
//    		offset = 0;
//    		for(int i = 0; i < currentNode.count; i++)
//    		{
//    			posList += 1;
//    			offset += 1;	
//    		}
//    	}
//    	offset = currentNode.count;
//    	
    	
    	
    }   
    /**
     * if has next element
     *
     */
    
    @Override
    public boolean hasNext()
    {
    	// TODO 
        if (posList == size)
    	{
        	return false;
    	}
    	return true;	
    }
    /**
     * return the next element
     *
     */
    @Override
    public E next()
    {
    	// TODO 
    	if(hasNext() == true)
    	{
    		posList += 1;
        	direction = BEHIND;
        	return find(posList).node.data[find(posList).offset];
    	}
    	return null;
    }
        
/**
 * remove the previous element or next element        
 */     
    @Override
    public void remove()
    {
    	// TODO 

    	if (direction == NONE)// if neither next nor previous have been called, 
    		                                      //or remove or add have been called after the last call to next or previous
    	{
    		throw new IllegalStateException();
    	}
    	if (direction == BEHIND)
    	{
        	StoutList.this.remove(nextIndex());
        	direction = NONE;
        	this.previous();
    	}
    	else if (direction == AHEAD)
    	{
    		StoutList.this.remove(previousIndex());
    		direction  = NONE;
    		this.next();
    	}
    	
    }
/**
 * if has previous element
 */
	@Override
	public boolean hasPrevious() {
		// TODO Auto-generated method stub
		if (posList == 0)
    	{
        	return false;
    	}
    	return true;	
	}
/**
 * return the previous element
 */

	@Override
	public E previous() {
		// TODO Auto-generated method stub
		if(hasPrevious() == true)
    	{
        	posList -= 1;
    		direction = AHEAD;
			return find(posList).node.data[find(posList).offset];
    	}
		return null;
	}
/**
 * return the index of next element
 * @return next index
 */
	@Override
	public int nextIndex() {
		// TODO Auto-generated method stub
		if (hasNext() == true)
		{
			posList += 1;
		}
		return posList;
	}
/**
 * return the index of previous element
 * @return previous index
 */
	@Override
	public int previousIndex() {
		// TODO Auto-generated method stub
		if (hasPrevious() == true)
		{
			posList -= 1;
		}
		return posList;	
		
	}
/**
 * set the element returned by next() or previous() index with the given element
 */
	@Override
	public void set(E e) {
		// TODO Auto-generated method stub
		
		if (e == null)
		{
			throw new NullPointerException();
		}
		if(direction == AHEAD) //previous
		{
			posList -= 1;
			find(posList).node.removeItem(find(posList).offset);
			find(posList).node.addItem(find(posList).offset, e);
//        	find(posList).node.data[find(posList).offset] = e;
        	direction = NONE;
		}
		else if (direction  == BEHIND) // next
		{
			posList += 1;
			find(posList).node.removeItem(find(posList).offset);
			find(posList).node.addItem(find(posList).offset, e);
//			find(posList).node.data[find(posList).offset] = e;
        	direction = NONE;
		}
		else //direction == NONE
		{ 
			return;
		}
	}
/**
 * add the given element to the previous or next postion 
 * @param the element to add
 */
	@Override
	public void add(E e) {
		// TODO Auto-generated method stub
		if (e == null)
    	{
    		throw new NullPointerException();
    	}
		if(direction  == AHEAD) // previous
		{
	    	StoutList.this.add(previousIndex(),e);
	    	direction = NONE;

		}
		else if(direction == BEHIND) // next
		{
	    	StoutList.this.add(nextIndex(),e);
	    	direction = NONE;

		}
		
	}
    
    // Other methods you may want to add or override that could possibly facilitate 
    // other operations, for instance, addition, access to the previous element, etc.
    // 
    // ...
    // 
  }
  

  /**
   * Sort an array arr[] using the insertion sort algorithm in the NON-DECREASING order. 
   * @param arr   array storing elements from the list 
   * @param comp  comparator used in sorting 
   */
  private void insertionSort(E[] arr, Comparator<? super E> comp)
  {
	  // TODO
	  int i = 0;
      int j = 0;
      E temp = null;  // Temporary variable for swap

      for (i = 1; i < arr.length; i++)
      {
    	  j = i;
    	  while(j > 0 && comp.compare(arr[j], arr[j - 1]) < 0)
    	  {
    		  temp = arr[j];
    		  arr[j] = arr[j - 1];
    		  arr[j - 1] = temp;
    		  
    	  }
      }
  }
  
  /**
   * Sort arr[] using the bubble sort algorithm in the NON-INCREASING order. For a 
   * description of bubble sort please refer to Section 6.1 in the project description. 
   * You must use the compareTo() method from an implementation of the Comparable 
   * interface by the class E or ? super E. 
   * @param arr  array holding elements from the list
   */
  private void bubbleSort(E[] arr)
  {
	  // TODO
	  int i, j;
	  int n = arr.length;
	  boolean swapped; 
	   for (i = 0; i < n-1; i++) 
	   { 
	     swapped = false; 
	     for (j = 0; j < n-i-1; j++) 
	     { 
		    if (arr[j].compareTo(arr[j+1]) > 0) 

	        { 
		    	E temp = arr[j];
		    	arr[j] = arr[j+1];
		    	arr[j+1] = temp;
		    	swapped = true; 
	        } 
	     } 
	  
	     // IF no two elements were swapped by inner loop, then break 
	     if (swapped == false) 
	        break; 
	   } 
  }
 
}

