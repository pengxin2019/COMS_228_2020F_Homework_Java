package edu.iastate.cs228.hw1;
/**
 * Junit Test for the TownCell class
 * @author Pengxin
 *
 */

public class TownCellTest 
{
	public static void main(String []args) 
	{
		Town town = new Town(4,4);
		town.randomInit(123);
		
		System.out.println(town);
		System.out.println(town.grid[1][2].nCensus[0]);
		System.out.println(town.grid[1][2].nCensus[1]);
		System.out.println(town.grid[1][2].nCensus[2]);
		System.out.println(town.grid[1][2].nCensus[3]);
		System.out.println(town.grid[1][2].nCensus[4]);

		
		
		
		
		
	}
	
	
	

}
