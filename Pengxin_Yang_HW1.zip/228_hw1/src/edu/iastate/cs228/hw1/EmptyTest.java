package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;

import org.junit.Test;
/**
 * Junit test for Empty class
 * @author Pengxin
 *
 */

public class EmptyTest 
{
	/**
	 * test the who() method of Empty
	 */
	@Test
	public void testWho()
	{
		Town town = new Town(3,4);
		Empty c = new Empty(town,1,2);
		assertEquals(c.who(), State.EMPTY);
	}

}
