package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;

import java.io.FileNotFoundException;

import org.junit.Test;
/**
 * Junit test for the Town class
 * @author Pengxin
 *
 */

public class TownTest {
	/**
	 * test the GetWidth() method
	 */
	@Test
	public void testGetWidth()
	{
		Town town = new Town(3,4);
		assertEquals(3, town.getWidth());
	}

}
