package edu.iastate.cs228.hw1;

import static org.junit.Assert.assertEquals;

import java.io.FileNotFoundException;

import org.junit.Test;
/**
 * Junit test for CasualTest
 * @author Pengxin
 *
 */

public class CasualTest
{
	/**
	 * test the who() method
	 */
	@Test
	public void testWho()
	{
		Town town = new Town(3,4);
		Casual c = new Casual(town,1,2);
		assertEquals(c.who(), State.CASUAL);
	}
	
}


	    

