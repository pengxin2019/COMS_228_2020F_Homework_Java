package edu.iastate.cs228.hw1;
/**
 *  subclass of abstract class TownCell
 * @author <<Pengxin Yang>>
 *	the cell type of the produced cell is Streamer
 *
 */

public class Streamer extends TownCell {
	/**
	 * construcotr of a Streamer
	 * @param p
	 * @param r
	 * @param c
	 */
	
	public 	Streamer (Town p, int r, int c) {
		// TODO Auto-generated constructor stub
		super(p, r, c);
	}
	/**
	 * a method which returns the state of the towncell
	 * @return the state of the towncell
	 * 
	 */

	@Override
	public State who() {
		// TODO Auto-generated method stub
		return State.STREAMER;
	}
	/**
	 * a method return a towncell which has the next state of the towncell 
	 * @return a new TownCell
	 */
	@Override
	public TownCell next(Town tNew) 
	{	
		if ((plain.grid[row][col].nCensus[EMPTY] +  plain.grid[row][col].nCensus[OUTAGE]) <= 1)
		{
			return new Reseller(tNew,row,col); 
		}
		if (plain.grid[row][col].nCensus[RESELLER] != 0)
		{
			return new Outage(tNew,row,col); 
		}
		else if(plain.grid[row][col].nCensus[OUTAGE] != 0)
		{
			return new Empty(tNew,row,col); 
		}
		
		else if(plain.grid[row][col].nCensus[CASUAL] > 4)
		{
			return new Streamer(tNew,row,col);
		}
		else
		{
			return new Streamer(tNew,row,col);
		}
		
	}
	

}
