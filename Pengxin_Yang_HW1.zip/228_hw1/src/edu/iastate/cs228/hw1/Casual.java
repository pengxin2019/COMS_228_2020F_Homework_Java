package edu.iastate.cs228.hw1;

public class Casual extends TownCell {
	

	public Casual(Town p, int r, int c) {
		// TODO Auto-generated constructor stub
		super(p, r, c);
	}

	@Override
	public State who() {
		// TODO Auto-generated method stub
		return State.CASUAL;
	}

	@Override
	public TownCell next(Town tNew) 
	{	
		if ((plain.grid[row][col].nCensus[EMPTY] +  plain.grid[row][col].nCensus[OUTAGE]) <= 1)
		{
			return new Reseller(tNew,row,col); 
		}
		if (plain.grid[row][col].nCensus[RESELLER] != 0)
		{
			return new Outage(tNew,row,col); 
		}
		else if(plain.grid[row][col].nCensus[STREAMER] != 0)
		{
			return new Streamer(tNew,row,col); 
		}
		
		else if(plain.grid[row][col].nCensus[CASUAL] > 4)
		{
			return new Streamer(tNew,row,col);
		}
		else
		{
			return new Casual(tNew,row,col);
		}
		
			
			
		
	}
}
 