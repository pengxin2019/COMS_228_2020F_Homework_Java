package edu.iastate.cs228.hw1;
/**
 * a subclass of abstract class TownCell
 * produce the Empty TownCell
 * @author Pengxin
 *
 */

public class Empty extends TownCell{
	/**
	 * constructor of Empty towncell
	 * @param p
	 * @param r
	 * @param c
	 */
	
	public 	Empty(Town p, int r, int c) {
		// TODO Auto-generated constructor stub
		super(p, r, c);
	}
	/**
	 * a method which return the state of the current Empty object
	 * @return state
	 */

	@Override
	public State who() {
		// TODO Auto-generated method stub
		return State.EMPTY;
	}
	/**
	 * a method return a new towncell which has the new state of the current Empty towncell
	 * @return new TownCell
	 */

	@Override
	public TownCell next(Town tNew) 
	{	
		if ((plain.grid[row][col].nCensus[EMPTY] +  plain.grid[row][col].nCensus[OUTAGE]) <= 1)
		{
			return new Reseller(tNew,row,col); 
		}
		else
		{
			return new Casual(tNew,row,col);
		}
		
	}

}
